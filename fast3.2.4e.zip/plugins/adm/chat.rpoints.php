<?php

// the rpoints chat command is now in roundspoints plugin

?>
