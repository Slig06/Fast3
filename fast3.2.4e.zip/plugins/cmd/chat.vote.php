<?php

// the vote chat command is now in vote plugin

?>
