<?php

// the ml chat command is now in manialinks plugin

?>
