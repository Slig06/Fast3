<?php

// the records chat command is now in records plugin

?>
